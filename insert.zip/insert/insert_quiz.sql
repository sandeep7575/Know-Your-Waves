select * from quiz;

use sample;
show tables;

insert into quiz values
(1, "Are you an international visitor?", "Do you know? International visitors are more likely to drown at beaches of Australia because of unknown and dangerous water habitats."),
(2, "Do you know how to swim?", "Fact: Do you know? Australian swimming standards are different than that of the rest of the world."),
(3, "Can you interpret the warning signs at Australian beaches?", "Do you know? Many tourists die at beaches because they ignore the warning signs."),
(4, "Are you traveling with children?", "Do you know? It takes less than 6 cm depth of water for your child to drown.");