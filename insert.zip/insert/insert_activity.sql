select * from activity;
create table activity (
activity_id int primary key,
activity_name varchar(100) not null,
precautionary_measure varchar(10000) not null);

INSERT INTO activity VALUES
    (1,'Snorkelling','For open water snorkeling carry visible swim buoy. It makes you noticeable for your snorkel buddy and other people in the ocean. Follow Weather forecast. Protect your skin from sun. Stay Hydrated but no alcohol. Dont swim on full stomach.'),
    (2,'Fishing','Check Weather conditions. Always tell friends or family of your plans where you are going and when you will be returning.Never fish alone. Wear a personal flotation device and carry safety gear and a first-aid kit. Watch the water at all times as conditions can change dramatically in a short time.'),
    (3,'Swimming','Bewar of the rip currents. Stay calm. If you see someone in trouble don''t dive in instead call the lifeguard. Dont  swim after meal or alcohol consumption. Swim between flags.'),
    (4,'Surfing','Protect Your head when you fall. Keep Hold of your surfboard. Learn about rip currents.Dont surf near obstacles like piers, exposed rocks, groynes,cliffs, boat.Wear surf safety gear. '),
    (5,'WaterSports','Watch weather, Wear a lifejacket if not a expert swimmer.Never go swimming or diving alone'),
    (6,'Picknicking','Keep plenty of water, food. Carry first aid box. Exercise extra caution in hot weather'),
    (7,'Walking','Be careful while walking on the rocks. Some rocks surfaces can be slippery'),
    (8,'Whale watching','Go slow when within 300m of whale. Approach at an angle and move away from the path of whale when leaving'),
    (9,'Not suitable for recreational activities','Not suitable for recreational activities'),
    (10,'Diving','Never go swimming or diving alone'),
    (11,'Rock fishing','Always wear a life jacket. Never fish alone. Inform others of your plans. Wear light clothing and appropriate footwear. Carry safety gear ?carry a rope and a float. Never fish in exposed areas during rough or large seas. Observe first, fish later. Plan an escape route in case you are washed in. Stay alert. Ask for advice from locals who know the area.'),
    (12,'Camping','Shose right weather. Pack and store food safely. Use Insect Protection. Stay Hydrated.'),
    (13,'Hiking','Shose right weather. Pack and store food safely. Use Insect Protection. Stay Hydrated. Apply Suncreen'),
    (14,'Wildlife','Keep safe distance from wildlife. Keep a safe distance. Feeding wildlife is not allowed.');
