use sample;
show tables;

select * from beach;

drop table beach;
create table beach (
beach_id int primary key,
beach_name varchar(100) not null,
suburb varchar(100) not null,
state varchar(5) not null,
postcode int,
lat float8 not null,
lon float8 not null,
PatrolInfo varchar(20),
HazardInfo text,
HazardRating int,
HazardDesc varchar(100)
);
INSERT INTO beach VALUES
    (1,'Port Melbourne Beach','Albert Park','VIC',3206,-37.84033,144.93264,'Patrolled',NULL,2,'Least Hazardous'),
    (2,'Station Pier Beach','Port Melbourne','VIC',3207,-38.00898,145.08604,'Unpatrolled','Bay Fishing',1,'Least Hazardous'),
    (3,'St Kilda Pier-Port Melbourne Beach','Port Melbourne','VIC',3207,-37.84033,144.93264,'Unpatrolled','Bay Fishing',1,'Least Hazardous'),
    (4,'Middle Park Beach','Middle Park','VIC',3206,-37.85339,144.95972,'Patrolled',NULL,3,'Least Hazardous'),
    (5,'Sandridge Beach','Port Melbourne','VIC',3207,-38.23191,147.37147,'Patrolled',NULL,2,'Least Hazardous'),
    (6,'St Kilda Pier Beach','St Kilda West','VIC',3182,-37.86069,144.97039,'Unpatrolled','Bay Fishing',1,'Least Hazardous'),
    (7,'St Kilda Beach','St Kilda South','VIC',3182,-37.86719,144.97403,'Patrolled','Swim close to Northern pier which is No Boating Zone',3,'Least Hazardous'),
    (8,'St Kilda Marina Beach','St Kilda South','VIC',3182,-37.87357,144.97543,'Unpatrolled','Swimming is safe activity as beach is surrounded by seawalls and groynes to prevent being washed away by longshore drift',2,'Least Hazardous'),
    (9,'Elwood Beach','Elwood','VIC',3184,-37.88687,144.98432,'Patrolled','Swimming is safe activity as beach is surrounded by seawalls and groynes to prevent being washed away by longshore drift',2,'Least Hazardous'),
    (10,'Middle Brighton Baths Beach','Brighton','VIC',3186,-37.90716,144.99728,'Patrolled','Swimming is safe activity as beach is surrounded by seawalls and groynes to prevent being washed away by longshore drift',3,'Least Hazardous'),
    (11,'Altona (Burns Reserve) Beach','Seaholme','VIC',3018,-37.86609,144.84487,'Unpatrolled','Swimming is only possible during High tides',1,'Least Hazardous'),
    (12,'Johanna Beach','Johanna','VIC',3238,-38.768021,143.389399,'Unpatrolled','Strong rips, so if you want to swim, stay on the bars and well clear of the rips',8,'Highly Hazardous'),
    (13,'Logans Beach','Warnambool','VIC',3280,-38.402391,142.513464,'Unpatrolled','Hazardour rip dominated Beach',7,'Highly Hazardous'),
    (14,'Otway Cove Beach','Cape Otway','VIC',3223,-38.828846,143.522906,'Unpatrolled','Unpatrolled and is considered Hazardous beach for swimming, surfing and fishing due to reef break offs and strong rips',7,'Highly Hazardous'),
    (15,'Bells Beach','Torquay','VIC',3228,-38.36431,144.28633,'Unpatrolled','Meccas for surfing due to strong rips and Winds. It is considered slightly dangerous for swimming',6,'Moderately Hazardous'),
    (16,'Ninety Mile Beach','Gippsland','VIC',3851,-38.21095,147.392,'Unpatrolled','Fishing, Swimming, Spotting whales, dolphins. Diving and snorkelling to explore the Marine Life near ocean',6,'Moderately Hazardous'),
    (17,'Bridgewater Bay Beach','Blairgowrie','VIC',3942,-38.37386,144.76693,'Unpatrolled','Beach is dominated by exposed rocks and reefs making it unsuitable for surfing and swimming. Best suitable for rock fishing during High tides',6,'Moderately Hazardous'),
    (18,'Discovery Bay Beach','Portland','VIC',3305,-38.20527,141.26504,'Unpatrolled','Hazardous, isolated beach very dangerous to swim and surf due to presence of rocks. However is suitable for rock fishing',8,'Highly Hazardous'),
    (19,'Balnarring Beach','Balnarring ','VIC',3926,-38.39019,145.12371,'Unpatrolled','Relatively safe beach for swimming',3,'Least Hazardous'),
    (20,'Eastern Beach','Geelong','VIC',3220,-38.14667,144.36916,'Patrolled','the deep trough and rips produce hazardous bathing conditions and a reasonable surf. So bathe between the flags and only surf with friends.',6,'Moderately Hazardous'),
    (21,'Cheviot Beach','Portsea','VIC',3944,-38.31346,144.66767,'Patrolled','Potentially hazardous beach due to presence of strong rips best suited for experienced swimmers and surfers',8,'Highly Hazardous'),
    (22,'Manns Beach ','Manns Beach','VIC',3971,-38.64503,146.77106,'Unpatrolled','Quiet place with a children''s plying area alongside beach. Suited for fishing ',6,'Moderately Hazardous'),
    (23,'Mentone Beach','Mentone','VIC',3194,-37.98748,145.05565,'Patrolled','Shallow surf zone popular for fishing on the groynes',3,'Least Hazardous'),
    (24,'Point Impossible Beach','Torquay','VIC',3228,-38.31205,144.36513,'Unpatrolled','Take care while swimming and watch for deep tidal channel and currents. Suitable for surfing during big winter swells',5,'Moderately Hazardous'),
    (25,'Mount Martha Point Beach','Mornington','VIC',3936,-38.265113,145.014198,'Unpatrolled','Relatively suited for rock fishing ',3,'Least Hazardous'),
    (26,'Safety Beach','Mornington','VIC',3936,-38.32578,144.97469,'Unpatrolled','Relatively safe during calm and low Winds waves however higher waves and rips during strong Winds',3,'Least Hazardous'),
    (27,'St. Andrew Beach','Mornington','VIC',3941,-38.41793,144.82947,'Unpatrolled','Beach is dominated by exposed rocks and reefs making it unsuitable for surfing and swimming. Best suitable for rock fishing during High tides',8,'Highly Hazardous'),
    (28,'Southside Beach','Torquay','VIC',3216,-38.37327,144.27515,'Unpatrolled','Potentially dangerous beach for swimming due to presence of rips. Suited for Rockfishing and surfing',7,'Highly Hazardous'),
    (29,'Sunnyside North Beach','Mount Eliza','VIC',3930,-38.20043,145.0625,'Unpatrolled','Fishing to be carried out on the rocks on either side of the beach. Suited for surfing and swimming. However care must be taken during high tides and strong rips to prevent from being washed away',3,'Least Hazardous'),
    (30,'Thirteenth Beach','Barwon Heada','VIC',3227,-38.28507,144.45878,'Unpatrolled','Popular surf spot suited for both learner and advanced surfers',5,'Moderately Hazardous'),
    (31,'Woodside Beach','Woodside','VIC',3874,-38.53166,146.97135,'Patrolled','Beware during strong Winds as wavesand rips intensify. Swim between the flags',5,'Moderately Hazardous'),
    (32,'Wreck Beach','Golden Beach','VIC',3851,-38.25269,147.35,'Unpatrolled','Dominated surf and strong rip currents make this beach unsuitable for swimming. Best suited for experienced surfers',8,'Highly Hazardous'),
    (33,'Kilcunda Beach','Kilcunda','VIC',3995,-38.549127,145.466633,'Unpatrolled','Rockpools is home to clusters of shell fish, tiny crabs, sea snails, small fish, seaweed or even starfish which children can explore.Railtrails and coastwalk can be used by avid walkers or bikers. Rock Fishing is popular.',7,'Highly Hazardous'),
    (34,'Shelley Beach','Kilcunda','VIC',3995,-38.550185,145.470174,'Unpatrolled','Popular for rockfishing and surfing',8,'Highly Hazardous'),
    (35,'Black Nose Point Beach','Portland','VIC',3305,-38.378665,141.641831,'Unpatrolled','Popular for surfing',8,'Highly Hazardous'),
    (36,'Penguin Parade, Philip Island Beach','Summerland','VIC',3922,-38.505277,145.14793,'Unpatrolled','Visitors can watch a penguin colony''s sunset waddle from the sea to their burrows. Also Popular for surfing, swimming and fishing',2,'Least Hazardous'),
    (37,'Wilsons Prom Beach','Wilsons Promontory','VIC',3960,-39.109046,146.274958,'Unpatrolled','River camping, hiking and exploring pictersque locations of Wilsons Prom.Beaches popular for surfing and fishing',6,'Moderately Hazardous');