select * from warning;

use sample;
show tables;

INSERT INTO warning VALUES
    (1,'Sharks '),
    (2,'Topographic rips'),
    (3,'Winds'),
    (4,'Strong Current'),
    (5,'High Tides'),
    (6,'Bluebottles'),
    (7,'Slippery rocks');